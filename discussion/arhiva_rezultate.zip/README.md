# Discussion — compararea surselor și ablații de prompt

Scripturi izolate pentru documentație / experimente. **Nu modifică** codul din `src/`.

## Structură

```
discussion/
  compare_hint_sources.py   # Tabel 1: bootstrap vs silver
  prompt_variants.py        # 6 variante de prompt (ablații)
  prompt_ablation_run.py    # 18 rulări LLM pe anon_1474_40.cpp
  output/                   # rezultate generate
  README.md
```

## Tabel 1 — compararea surselor

```bash
python discussion/compare_hint_sources.py
```

Scrie:
- `discussion/output/TABLE1_hint_sources.md`
- `discussion/output/TABLE1_hint_sources.csv`

## Ablație prompt (6 × 3 = 18 rulări)

Caz implicit: `2021_adrese/anon_1474_40.cpp` (problemă `2021_tema2_adrese`),
pereche 100p: `anon_1474_100.cpp`.

| ID variantă | Descriere |
|---|---|
| `bootstrap` | Prompt producție bootstrap |
| `silver` | Prompt producție silver |
| `bootstrap_no_pitfalls` | Bootstrap fără `common_pitfalls` |
| `bootstrap_no_concepts` | Bootstrap fără `concepts_dag` |
| `silver_full_diff` | Silver + diff textual + unified + cod 100p |
| `silver_no_passing` | Silver + ambele diff-uri, fără cod 100p |

Temperaturi: **0.2, 0.6, 0.9**.

```bash
# Verifică prompturile fără Ollama
python discussion/prompt_ablation_run.py --dry-run

# Rulează cele 18 apeluri (necesită ollama serve + gpt-oss:20b)
python discussion/prompt_ablation_run.py
```

Scrie:
- `discussion/output/ablation_anon_1474_adrese.jsonl` (un rând per rulare)
- `discussion/output/ablation_anon_1474_adrese.md` (tabel sumar)

## Cerințe

- Python env cu dependențele din `requirements.txt`
- Pentru ablație: Ollama local (`OLLAMA_MODEL`, implicit `gpt-oss:20b`)

## De ce silver poate eșua în ablație (și fix)

**Nu s-a schimbat `prompt_builder.py`.** Promptul silver e același ca la
`silver_hints.py` (vezi `silver_diff.jsonl` — `anon_1474_40.cpp` a trecut).

Problema: `gpt-oss:20b` + `format="json"` + system prompt lung (silver ~4240
car. vs bootstrap ~1860) → Ollama returnează uneori `message.content` gol.
Bug cunoscut la modele reasoning în Ollama.

`discussion/ollama_helpers.py` aplică:
- `num_ctx=16384` (implicit)
- `think: "low"` pentru gpt-oss
- retry fără `format=json` + extragere JSON manuală

Re-rulează doar silver eșuate:
```bash
python discussion/prompt_ablation_run.py --only silver,silver_full_diff,silver_no_passing --retry-failed
```
